exports.handler = async (event) => {
    
    const {
      TranscribeClient,
      StartTranscriptionJobCommand,
    } = require("@aws-sdk/client-transcribe");

    // TODO implement
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
};
